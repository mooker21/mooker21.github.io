package com.member.service;

import java.util.List;

import com.member.dto.MemberVO;

public interface MemberService {

    public List<MemberVO> selectMember() throws Exception;

}
