package com.member.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.member.dto.MemberVO;

public interface MemberDAO {

//	@Select("SELECT NOW()")
//	public String getTime();
	
	public List<MemberVO> selectMember() throws Exception;

}
